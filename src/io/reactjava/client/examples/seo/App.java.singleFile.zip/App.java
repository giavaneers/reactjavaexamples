/*==============================================================================

name:       App.java

purpose:    SEO App.

history:    Tue Dec 17, 2019 10:30:00 (Giavaneers - LBM) created

notes:

                        COPYRIGHT (c) BY GIAVANEERS, INC.
         This source code is licensed under the MIT license found in the
             LICENSE file in the root directory of this source tree.

==============================================================================*/
                                       // package --------------------------- //
package io.reactjava.client.examples.seo;
                                       // imports --------------------------- //
import elemental2.dom.DomGlobal;
import elemental2.dom.Element;
import elemental2.dom.HTMLMetaElement;
import elemental2.dom.HTMLScriptElement;
import elemental2.dom.HTMLTitleElement;
import elemental2.dom.Node;
import elemental2.dom.NodeList;
import io.reactjava.client.core.react.AppComponentTemplate;
import io.reactjava.client.core.react.Component;
import io.reactjava.client.core.react.Properties;
import io.reactjava.client.core.react.ReactJava;
import io.reactjava.client.core.react.SEOInfo;
import io.reactjava.client.core.react.SEOInfo.SEOPageInfo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
                                       // App ================================//
public class App extends AppComponentTemplate
{
                                       // class constants --------------------//
                                       // route paths                         //
public static final String kPATH_A       = "ViewA";
public static final String kPATH_B       = "ViewB";
public static final String kPATH_DEFAULT = "";

                                       // component class                     //
public static final Map<String,Class> kAPP_ROUTES =
   Collections.unmodifiableMap(
      new HashMap<String,Class>()
      {
         {
            put(kPATH_A,       ViewA.class);
            put(kPATH_B,       ViewB.class);
            put(kPATH_DEFAULT, ViewA.class);
         }
      });

public static final String kSEO_DEPLOY_PATH     = "http://www.reactjava.io";

public static final String kTITLE_LANDING       = "ReactJava";
public static final String kTITLE_USER_GUIDE    = "ReactJava User Guide";

public static final String kDESCRIPTION_LANDING =
   "Use Java to build the same great applications for mobile and the desktop "
 + "as you do with React and React Native. The same powerful features of React "
 + "you expect: lightweight, declarative, performant, component-based "
 + "programming that is simple to write and easy to debug; packaged in a way "
 + "that naturally combines the structure, familiarity, and reach of Java. "
 + "And targeting native mobile environments is often right out of the box. "
 + "In most cases, ReactJava automatically translates your ReactJava "
 + "components to React Native equivalents.";

public static final String kDESCRIPTION_USER_GUIDE =
   "The ReactJava User Guide includes a simple tutorial that is a step by step "
 + "illustration of how ReactJava works and how you can use it to build a "
 + "React app using Java.";
                                       // class variables ------------------- //
                                       // (none)                              //
                                       // public instance variables --------- //
                                       // (none)                              //
                                       // protected instance variables -------//
                                       // (none)                              //
                                       // private instance variables -------- //
                                       // (none)                              //
/*------------------------------------------------------------------------------

@name       getNavRoutes - get navigation routes for application
                                                                              */
                                                                             /**
            Get map of component classname by route path.

@return     void

@history    Thu Feb 14, 2019 10:30:00 (Giavaneers - LBM) created

@notes
                                                                              */
//------------------------------------------------------------------------------
protected Map<String,Class> getNavRoutes()
{
   return(kAPP_ROUTES);
}
/*------------------------------------------------------------------------------

@name       getSEOInfo - get seo information
                                                                              */
                                                                             /**
            Get SEO info. This method is typically invoked at compile time.

            The intention is to provide a title, description, and base url for
            the app deployment in order to create a redirect target for each
            hash, along with an associated sitemap.

@return     SEOInfo string

@history    Tue Dec 17, 2019 10:30:00 (Giavaneers - LBM) created

@notes
                                                                              */
//------------------------------------------------------------------------------
@Override
protected SEOInfo getSEOInfo()
{
   SEOInfo seoInfo =
      new SEOInfo(
         kSEO_DEPLOY_PATH,
         new ArrayList<>(
            Arrays.asList(
               new SEOPageInfo(
                  kPATH_A,
                  kTITLE_LANDING,
                  kDESCRIPTION_LANDING),
               new SEOPageInfo(
                  kPATH_B,
                  kTITLE_USER_GUIDE,
                  kDESCRIPTION_USER_GUIDE)
            )));

   return(seoInfo);
}
/*==============================================================================

name:       View

purpose:    App base view

history:    Mon Jun 26, 2017 10:30:00 (Giavaneers - LBM) created

notes:

==============================================================================*/
public static class View<P extends Properties> extends Component
{                                       // constants ------------------------- //
                                       // (none)                              //
                                       // class variables ------------------- //
                                       // (none)                              //
                                       // public instance variables --------- //
                                       // (none)                              //
                                       // protected instance variables ------ //
                                       // (none)                              //

/*------------------------------------------------------------------------------

@name       render - render markup
                                                                              */
                                                                             /**
            Render markup.

@return     void

@history    Tue Dec 17, 2019 10:30:00 (Giavaneers - LBM) created

@notes

                                                                              */
//------------------------------------------------------------------------------
public void render()
{
                                       // seo support...                      //
   super.render();
/*--

--*/
                                       // check seo result after rendering    //
   DomGlobal.setTimeout(
      (e) ->
      {
         seoCheck();
      }, 1000);
}
/*------------------------------------------------------------------------------

@name       seoCheck - check seo result
                                                                              */
                                                                             /**
            Check seo result.

@return     void

@history    Tue Dec 17, 2019 10:30:00 (Giavaneers - LBM) created

@notes

                                                                              */
//------------------------------------------------------------------------------
public void seoCheck()
{
   seoCheckHeadElements();
}
/*------------------------------------------------------------------------------

@name       seoCheckHeadElements - check seo inserted head elements
                                                                              */
                                                                             /**
            Check seo inserted head elements.

@return     void

@history    Tue Dec 17, 2019 10:30:00 (Giavaneers - LBM) created

@notes

                                                                              */
//------------------------------------------------------------------------------
public void seoCheckHeadElements()
{
   String   sMeta       = null;
   String   sTitle      = null;
   String   sStructured = null;
   NodeList children   = DomGlobal.document.head.childNodes;
   for (int i = 0, iMax = children.length;
         i < iMax && (sMeta == null || sTitle == null || sStructured == null);
         i++)
   {
      Node child = (Node)children.item(i);
      if (child.nodeType == Node.ELEMENT_NODE)
      {
         switch (((Element)child).tagName)
         {
            case ReactJava.kHEAD_ELEM_TYPE_META:
            {
               HTMLMetaElement meta = (HTMLMetaElement)child;
               sMeta = "name=" + meta.name + ", content=" + meta.content;
               break;
            }
            case ReactJava.kHEAD_ELEM_TYPE_STRUCTURED:
            {
               HTMLScriptElement script = (HTMLScriptElement)child;
               sStructured = "script=" + script.text;
               break;
            }
            case ReactJava.kHEAD_ELEM_TYPE_TITLE:
            {
               HTMLTitleElement title = (HTMLTitleElement)child;
               sTitle = "text=" + title.text;
               break;
            }
         }
      }
   }

   sTitle = sTitle;
}
}//====================================// end View ===========================//
/*==============================================================================

name:       ViewA

purpose:    App view A

history:    Mon Jun 26, 2017 10:30:00 (Giavaneers - LBM) created

notes:

==============================================================================*/
public static class ViewA extends View
{                                       // constants ------------------------- //
                                       // (none)                              //
                                       // class variables ------------------- //
                                       // (none)                              //
                                       // public instance variables --------- //
                                       // (none)                              //
                                       // protected instance variables ------ //
                                       // (none)                              //

}//====================================// end ViewA ==========================//
/*==============================================================================

name:       ViewB

purpose:    App view B

history:    Mon Jun 26, 2017 10:30:00 (Giavaneers - LBM) created

notes:

==============================================================================*/
public static class ViewB extends View
{                                       // constants ------------------------- //
                                       // (none)                              //
                                       // class variables ------------------- //
                                       // (none)                              //
                                       // public instance variables --------- //
                                       // (none)                              //
                                       // protected instance variables ------ //
                                       // (none)                              //

}//====================================// end ViewB ==========================//
}//====================================// end App ============================//
